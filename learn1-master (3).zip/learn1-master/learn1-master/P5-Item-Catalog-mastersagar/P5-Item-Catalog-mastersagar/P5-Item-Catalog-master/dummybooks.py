from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from database_setup import Base, BookDB, User

engine = create_engine('sqlite:///BookCatalog.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)

session = DBSession()

# Create dummy user
User1 = User(name="sourav", email="ray.sourav26@gmail.com")
session.add(User1)
session.commit()

# Dummy books data
book1 = BookDB(bookName="I Too Had a Love Story",
               authorName="Ravinder Singh",
               coverUrl="""https://upload.wikimedia.org/wikipedia/en/thumb/d/d1/I_Too_Had_a_Love_Story_front_cover.jpg/220px-I_Too_Had_a_Love_Story_front_cover.jpg""",
               description="ravinder", category="Romance", user_id=1)

session.add(book1)
session.commit()

book2 = BookDB(bookName="Can Love Happen Twice",
               authorName="Ravinder Singh",
               coverUrl="""https://n2.sdlcdn.com/imgs/b/e/y/Can-Love-Happen-Twice-SDL008162029-1-a83dd.jpg""",
               description="ravinder", category="Romance", user_id=1)

session.add(book2)
session.commit()

book3 = BookDB(bookName="The Immortals of Meluha",
               authorName="Amish Tripathi",
               coverUrl="""https://upload.wikimedia.org/wikipedia/en/archive/0/0e/20180110001413%21The_Immortals_Of_Meluha.jpg""",
               description="Amish", category="Fantasy", user_id=1)

session.add(book3)
session.commit()

book4 = BookDB(bookName="The Swastika Killer",
               authorName="Mahendra Jakhar",
               coverUrl="""https://images-na.ssl-images-amazon.com/images/I/81oljLb-HyL.jpg""",
               description="Mahendra", category="Mystery", user_id=1)

session.add(book4)
session.commit()

book5 = BookDB(bookName="A Face in the Dark and Other Hauntings",
               authorName="Ruskin Bond",
               coverUrl="""https://images.gr-assets.com/books/1175060032l/475193.jpg""",
               description="hello", category="Horror", user_id=1)

session.add(book5)
session.commit()


print "added Books!"
